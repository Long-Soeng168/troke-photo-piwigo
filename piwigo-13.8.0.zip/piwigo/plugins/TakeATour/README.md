# Piwigo TakeATour

* Internal name: `TakeATour` (directory name in `plugins/`)
* Plugin page: http://piwigo.org/ext/extension_view.php?eid=776
* Translation: http://piwigo.org/translate/project.php?project=takeatour
