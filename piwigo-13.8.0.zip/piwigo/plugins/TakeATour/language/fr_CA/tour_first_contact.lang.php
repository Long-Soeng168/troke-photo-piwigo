<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['first_contact_title1'] = 'Bienvenue dans votre galerie Piwigo';
$lang['first_contact_stp13'] = 'Vous pouvez éditer les descriptions, mots-clés et autres propriétés depuis la gestion par lot en mode unitaire. Mais pour le moment, restons en mode global.';