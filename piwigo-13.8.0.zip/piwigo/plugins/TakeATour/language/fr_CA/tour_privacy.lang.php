<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['privacy_stp9'] = '... et sélectionnez l\'action "Qui peut voir les photos ?". Vous pouvez ainsi définir le niveau de confidentialité des photos sélectionnées.<br><br>Mais vous pouvez aussi le faire pour une photo spécifique, sur sa page d\'édition. Vous pouvez y accéder depuis la partie publique, ou à partir d\'ici.<br><br>Maintenant, voyons l\'autre système de permissions pour les albums fondés sur les groupes et les utilisateurs.';