<?php
$lang['2_7_0_stp4'] = '';
$lang['2_7_0_stp5'] = '';
$lang['2_7_0_stp6'] = '';
$lang['2_7_0_title4'] = 'Pagina de cautare';
$lang['2_7_0_title5'] = 'Timpul';
$lang['2_7_0_title6'] = 'Selecteaza scriptul';
$lang['2_7_0_title1'] = 'Bine ai venit in Piwigo 2.7';
$lang['2_7_0_title11'] = 'La revedere!';
$lang['2_7_0_stp11'] = 'Turul s-a incheiat.<p style="text-align:center">Bucura-te de Piwigo 2.7!</p> Daca ti-a placut Piwigo si vrei sa ne ajuti poti contribui cu traduceri, donatii, etc.  <a href="http://piwigo.org/basics/contribute" target="_blank">Apasa aici pentru a ne ajuta.</a>
Multumim!';
$lang['2_7_0_stp1'] = 'Buna! Eu voi fi ghidul tau in Piwigo. Te rog urmeaza instructiunile date si apasa Next (sau folseste sagetile de pe tastatura). Daca navighezi catre alta pagina vei fi redirectat  catre pagina curenta a turului.';
