<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['2_9_0_title7'] = 'Reĝimo de etikeda elekto';
$lang['2_9_0_title3'] = 'Opcioj por albumo forigado';
$lang['2_9_0_stp5'] = 'Trovi duobligajn fotojn per kontrolsumo (sama enhavo)';
$lang['2_9_0_title6'] = 'Nuna monata historio';
$lang['2_9_0_title5'] = 'Duobloj de kontrolsumo';
$lang['2_9_0_stp6'] = 'Defaŭlte, historio nun malfermiĝas en nuna monata statistiko';
$lang['2_9_0_title2'] = 'Generilo de pasvorto';
$lang['2_9_0_title1'] = 'Bonvenon en Piwigo 2.9';
$lang['2_9_0_title4'] = 'Elŝuti foton';