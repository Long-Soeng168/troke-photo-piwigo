<?php
// +-----------------------------------------------------------------------+
// | Piwigo - a PHP based photo gallery                                    |
// +-----------------------------------------------------------------------+
// | Copyright(C) 2008-2015 Piwigo Team                  http://piwigo.org |
// | Copyright(C) 2003-2008 PhpWebGallery Team    http://phpwebgallery.net |
// | Copyright(C) 2002-2003 Pierrick LE GALL   http://le-gall.net/pierrick |
// +-----------------------------------------------------------------------+
// | This program is free software; you can redistribute it and/or modify  |
// | it under the terms of the GNU General Public License as published by  |
// | the Free Software Foundation                                          |
// |                                                                       |
// | This program is distributed in the hope that it will be useful, but   |
// | WITHOUT ANY WARRANTY; without even the implied warranty of            |
// | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU      |
// | General Public License for more details.                              |
// |                                                                       |
// | You should have received a copy of the GNU General Public License     |
// | along with this program; if not, write to the Free Software           |
// | Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, |
// | USA.                                                                  |
// +-----------------------------------------------------------------------+
$lang['2_8_0_stp3'] = 'Ja no cal que els usuaris s\'hagin de recordar de la contrasenya mai més.<br><br> Podran accedir al seu contingut privat directament i amb seguretat.  ';
$lang['2_8_0_stp4'] = 'Ara es possible de repetir una marca d\'aigua en diferents línies. <br><br> Indica el valor <em> Y repeat </em> configurant-ho a 1 o 2 per obtenir la repetició.';
$lang['2_8_0_stp2'] = 'En notificar un àlbum per correu electrònic, Piwigo 2.8 permet seleccionar els usuaris va dirigit i no solament a grups  ';
$lang['2_8_0_stp5'] = 'En eliminar un àlbum algunes pot passar que algunes fotos quedin orfes. Piwigo 2.8 les fa òbvies...';
$lang['2_8_0_title5'] = 'Orfes';
$lang['2_8_0_title6'] = 'Orfes';
$lang['2_8_0_stp6'] = '... i deixat seduir amb només un click!';
$lang['2_8_0_title1'] = 'Benvingut a Piwigo 2.8';
$lang['2_8_0_title2'] = 'Avisa un usuari';
$lang['2_8_0_title3'] = 'Claus d\'autenticació';
$lang['2_8_0_title4'] = 'Marca d\'aigua';
$lang['2_8_0_stp1'] = 'Els detalls d\'usuari ja no surten en la llista d\'usuaris, només s\'obté un formulari orientat a un únic usuari. <br><br> Piwigo 2.8 també arregla alguns errors com de la llista d\'usuaris com la verificació d\'adreces de correu electrònic. ';