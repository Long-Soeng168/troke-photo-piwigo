<?php
$lang['2_7_0_stp4'] = 'Stran Iskanja je bila prenoveljena: možnost izbire lastnosti na katero se nanaša iskana beseda, seznam avtorjev najdenih v podatkovni bazi, samodejno dokončani seznam oznak, samodejno dokončani seznam albumov...';
$lang['2_7_0_stp5'] = 'Poleg datuma lahko z uporabo drsnikov Ura in Minute nastavite tudi čas';
$lang['2_7_0_stp6'] = 'Izbirnik polj za izbrane albume, oznake itd. je spremenjen in je bolj prijazen uporabniku.
Preizkusite tu spodaj.';
$lang['2_7_0_title4'] = 'Stran iskanja';
$lang['2_7_0_title5'] = 'Čas';
$lang['2_7_0_title6'] = 'Izberi sklope';
$lang['2_7_0_title2'] = 'Prva nova funkcija';
$lang['2_7_0_title11'] = 'Vidimo se kmalu!';
$lang['2_7_0_title1'] = 'Dobrodošli v Piwigo 2.7';
$lang['2_7_0_stp2'] = 'Kot lahko vidite, je bil dodan nov privzet vtičnik: Oglejte si predstavitev. Ta vtičnik vam pomaga, da spoznate Piwigo. Tu so navedene vse razpoložljive predstavitve. <br> Predstavitve so na voljo v <em> Vtičniki >> Začni predtavitev </em>';
$lang['2_7_0_stp11'] = 'Ta predstavitev je končana. <p style="text-align:center"> Uživajte v Piwigo 2.7! </p> Če vam je všeč Piwigo in želite, podpreti naš projekt, lahko prispevate s pomočjo prevodov, donacijami, itd. <a href= "http://piwigo.org/basics/contribute" target = "_blank"> Za podporo kliknite tukaj. Hvala! </a>';
$lang['2_7_0_stp1'] = 'Pozdravljeni! Jaz bom vaš vodič, pri spoznavanju Piwigo. Prosimo, da sledite mojim navodilom, in kliknite Naprej (ali uporabite puščice na tipkovnici) za navigacijo. Če greste na drugo stran, boste preusmerjeni na trenutno stran Predstavitve.';
$lang['2_7_0_stp10'] = 'Dodan je bil tudi Filter velikosti datoteke v Skupinski urejevalnik. Izberete lahko razpon men min. in max vrednostjo.';
$lang['2_7_0_stp9'] = 'Iskalni filter je bil dodan v Skupinski urejevalnik. Vsebuje mogočno sintakso za iskanje fotografij po datumu, oznakah, velikosti, imenu datoteke, pa tudi iskalne možnosti, kot natančno ujemanje, IN/ALI, grupiranje, izključitev...; Podrobno pomoč lahko preberete kasneje. Ista sintaksa velja za polje hitrega iskanja na meniju javne strani.';
$lang['2_7_0_stp7'] = 'Sedaj lahko vaše albume razvrstite po datumu nastanka fotografij ali po datumu objave fotografij';
$lang['2_7_0_stp8'] = 'Preprosta povezava za izpraznitev vaše košarice z enim klikom';
$lang['2_7_0_stp2b'] = 'Nov obrazec za nalaganje slik v Piwigo 2.7 temelji na HTML5 namesto Flash obrazca, kar pomeni boljšo skladnost z modernimi brskalniki in večjo zanesljivost pri počasnih povezavah. Možnost povleci & spusti močno poenostavi izbor slik iz vašega računalnika, ki jih želite dodati v galerijo Piwigo.';
$lang['2_7_0_title7'] = 'Razvrstitev albumov po datumu';
$lang['2_7_0_title2b'] = 'Nov obrazec nalaganja';
$lang['2_7_0_title10'] = 'Filter velikosti datoteke';
$lang['2_7_0_title8'] = 'Izpraznite vašo košarico';
$lang['2_7_0_title9'] = 'Iskalni filter';