<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['first_contact_stp15'] = 'このページでは、あなたは写真の全ての特徴を編集できます。例えば...';
$lang['first_contact_stp11'] = 'ここから、あなたは1つ以上の写真を選択できます';
$lang['first_contact_stp12'] = 'そしてアクションを用いてそれらを編集できます';
$lang['first_contact_stp19_b'] = 'ここにあるのは、’ルート’アルバムのリストです。';
$lang['first_contact_stp2'] = 'リンクはここにあります。これをクリックするか、次をクリックして続けます。';
$lang['first_contact_stp22'] = '写真のように、あなたはアルバムの特徴を編集できます';
$lang['first_contact_stp30'] = 'タイトルを変更することから始めよう';
$lang['first_contact_stp32'] = '今あなたの変更を保存する';
$lang['first_contact_stp35'] = 'あなたの好みのテーマをデフォルトテーマに設定する';
$lang['first_contact_stp4'] = 'はじめにアルバムを選択する。もしアルバムがなければ1つ作成する';
$lang['first_contact_stp8'] = 'それらを編集しよう！リンクをクリックしてください。';
$lang['first_contact_title1'] = 'あなたのPiwigoギャラリーへようこそ';
$lang['first_contact_title11'] = '写真の編集方法';
$lang['first_contact_title15'] = '写真の編集ページ';
$lang['first_contact_title18'] = 'アルバムを管理する';
$lang['first_contact_title19'] = 'アルバムを管理する';
$lang['first_contact_title20'] = 'アルバムを管理する';
$lang['first_contact_title21'] = '他のタブ';
$lang['first_contact_title22'] = 'アルバム編集ページ';
$lang['first_contact_title28'] = '設定';
$lang['first_contact_title29'] = '<em>設定 » オプション » 一般</em>';
$lang['first_contact_title3'] = '写真ページを追加する';
$lang['first_contact_title33'] = 'ゲストの設定';
$lang['first_contact_title34'] = 'テーマ';
$lang['first_contact_title35'] = 'テーマ';
$lang['first_contact_title37'] = 'テーマ';
$lang['first_contact_title38'] = 'プラグイン';
$lang['first_contact_title39'] = 'プラグイン';
$lang['first_contact_title4'] = '写真を追加しよう！';
$lang['first_contact_title9'] = 'バッチ管理';