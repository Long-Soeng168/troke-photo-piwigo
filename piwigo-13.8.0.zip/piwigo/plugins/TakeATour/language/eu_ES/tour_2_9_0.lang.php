<?php
// +-----------------------------------------------------------------------+
// | This file is part of Piwigo.                                          |
// |                                                                       |
// | For copyright and license information, please view the COPYING.txt    |
// | file that was distributed with this source code.                      |
// +-----------------------------------------------------------------------+
$lang['2_9_0_stp4'] = 'Deskargatzeko esteka argazkiak editatzeko orrian, administrarientzat.';
$lang['2_9_0_stp5'] = 'Bikoiztutako argazkiak aurkitzeko aukera checksum erabiliz';
$lang['2_9_0_stp6'] = 'Historiala uneko hilabetearen estatistikekin irekitzen da modu lehenetsian';
$lang['2_9_0_stp7'] = 'Taldeko ekintzak baimentzen duen etiketa kudeatzailearen hautaketa modu berria.<br><br>Egin klik estekan hautaketa modura aldatzeko';
$lang['2_9_0_title1'] = 'Ongi etorri Piwigo 2.9ra';
$lang['2_9_0_title2'] = 'Pasahitz-sortzailea';
$lang['2_9_0_title3'] = 'Albumak ezabatzeko aukerak';
$lang['2_9_0_title4'] = 'Deskargatu argazkia';
$lang['2_9_0_title5'] = 'Bikoiztuak checksum-en';
$lang['2_9_0_title6'] = 'Uneko hilabetearen historiala';
$lang['2_9_0_title7'] = 'Etiketen hautaketa modua';
$lang['2_9_0_stp3'] = 'Argazkiak dituen albuma ezabatzerakoan, Piwigok orain ea albumarekin erlazionatutako argazkiekin zer egin nahi duzun itaunduko dizu.<br><br>Egin klik ezabatzeko estekan nola funtzionatzen duen ikusteko (gero bertan behera uzteko aukera duzu)';
$lang['2_9_0_stp2'] = '2.9 bertsioak pasahitz-sortzailea txertaturik dakar zuzenean erabiltzaile berriek formularioan.<br><br>Egin klik hemen nola funtzionatzen duen ikusteko!';
$lang['2_9_0_stp1'] = '2.9 bertsioaren aldaketarik nagusiena: Diseinua! Goiburu, orri-oin eta menu-barra ilunak. Ertz gutxiago.<br><br>Administrazioaren hasiera-orri guztiz berritua, ikono handiagoekin eta sarrera zuzenekin orri nagusietara.';