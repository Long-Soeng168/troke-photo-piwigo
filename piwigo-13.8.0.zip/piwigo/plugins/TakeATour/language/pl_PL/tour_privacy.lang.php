<?php
$lang['privacy_title14b'] = '';
$lang['privacy_stp14b'] = 'Ważny fakt: webmastrzy i administratorzy nie są wszechwiedzący w trakcie przeglądania części publicznej, ale mają dostęp do każdego albumu i zdjęcia w sekcji administracyjnej.';
